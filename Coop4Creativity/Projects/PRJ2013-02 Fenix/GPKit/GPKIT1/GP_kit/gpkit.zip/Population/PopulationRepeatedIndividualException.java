/* -------------------------------------------------------------------------- */
/* Classe    : PopulationRepeatedIndividualException                          */
/* Excep��o                                                                   */
/* Descri��o : Excep��es relativas � classe Population                        */
/* -------------------------------------------------------------------------- */

package Population;

public class PopulationRepeatedIndividualException extends Exception
{
/* ----------------------------- constructores ------------------------------ */

public PopulationRepeatedIndividualException ()
  {  super();  }
public PopulationRepeatedIndividualException (String message)
  {  super(message);  }
}

/* -------------------------------------------------------------------------- */